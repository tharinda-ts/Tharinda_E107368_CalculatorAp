﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace nov_9th
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)

        {
            float num1, num2;
            if (!float.TryParse(txt_number1.Text, out num1) || !float.TryParse(txt_number2.Text, out num2))
                    {
                MessageBox.Show("Enter only numbers");
                return;
            }
            float Add = num1 + num2;
            txt_answer.Text = Add.ToString();
        }   
        

        private void label1_Click(object sender, EventArgs e)
        {
           

        }

        public void txt_number2_TextChanged(object sender, EventArgs e)
        {
        }

        private void btn_sub_Click(object sender, EventArgs e)
        {
            float num1, num2;
            if (!float.TryParse(txt_number1.Text, out num1)||!float.TryParse(txt_number2.Text, out num2))
            {
                MessageBox.Show("Enter only numbers");
                return;
            }
            float Sub = num1 - num2;
            txt_answer.Text = Sub.ToString();
            {


            }
        }

        private void btn_multiply_Click(object sender, EventArgs e)
        {
            float num1, num2;
            if (!float.TryParse(txt_number1.Text, out num1)||!float.TryParse(txt_number2.Text, out num2))
            {
                MessageBox.Show("Enter only numbers");
                return;
            }
            float multiply = num1 * num2;
            txt_answer.Text = multiply.ToString();
        }

        private void btn_divide_Click(object sender, EventArgs e)
        {
            float num1, num2;
            if (!float.TryParse(txt_number1.Text, out num1) || !float.TryParse(txt_number2.Text, out num2))
            {
                MessageBox.Show("Enter only numbers");
                return;
            }
                if 
                (num2 == 0)
                {               
                MessageBox.Show("Invalid Answer");
                return;
                }
            float Divide = num1 / num2;
            txt_answer.Text = Divide.ToString();
        }

        private void lbl_number1_Click(object sender, EventArgs e)
        {

        }
    }
}
