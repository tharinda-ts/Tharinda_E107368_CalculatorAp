﻿namespace nov_9th
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txt_number1 = new System.Windows.Forms.TextBox();
            this.txt_number2 = new System.Windows.Forms.TextBox();
            this.lbl_number1 = new System.Windows.Forms.Label();
            this.lbl_number2 = new System.Windows.Forms.Label();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_divide = new System.Windows.Forms.Button();
            this.btn_multiply = new System.Windows.Forms.Button();
            this.btn_sub = new System.Windows.Forms.Button();
            this.lbl_answer = new System.Windows.Forms.Label();
            this.txt_answer = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txt_number1
            // 
            this.txt_number1.Location = new System.Drawing.Point(300, 69);
            this.txt_number1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_number1.Name = "txt_number1";
            this.txt_number1.Size = new System.Drawing.Size(364, 34);
            this.txt_number1.TabIndex = 0;
            this.txt_number1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txt_number2
            // 
            this.txt_number2.Location = new System.Drawing.Point(300, 191);
            this.txt_number2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_number2.Name = "txt_number2";
            this.txt_number2.Size = new System.Drawing.Size(364, 34);
            this.txt_number2.TabIndex = 1;
            this.txt_number2.TextChanged += new System.EventHandler(this.txt_number2_TextChanged);
            // 
            // lbl_number1
            // 
            this.lbl_number1.AutoSize = true;
            this.lbl_number1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lbl_number1.Location = new System.Drawing.Point(117, 74);
            this.lbl_number1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_number1.Name = "lbl_number1";
            this.lbl_number1.Size = new System.Drawing.Size(112, 27);
            this.lbl_number1.TabIndex = 2;
            this.lbl_number1.Text = "NUMBER 1";
            this.lbl_number1.Click += new System.EventHandler(this.lbl_number1_Click);
            // 
            // lbl_number2
            // 
            this.lbl_number2.AutoSize = true;
            this.lbl_number2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_number2.Location = new System.Drawing.Point(117, 201);
            this.lbl_number2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_number2.Name = "lbl_number2";
            this.lbl_number2.Size = new System.Drawing.Size(112, 27);
            this.lbl_number2.TabIndex = 3;
            this.lbl_number2.Text = "NUMBER 2";
            // 
            // btn_add
            // 
            this.btn_add.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btn_add.Font = new System.Drawing.Font("Arial Black", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_add.Location = new System.Drawing.Point(713, 69);
            this.btn_add.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(112, 107);
            this.btn_add.TabIndex = 4;
            this.btn_add.Text = "+";
            this.btn_add.UseVisualStyleBackColor = false;
            this.btn_add.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_divide
            // 
            this.btn_divide.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btn_divide.Font = new System.Drawing.Font("Arial Black", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_divide.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_divide.Location = new System.Drawing.Point(828, 180);
            this.btn_divide.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_divide.Name = "btn_divide";
            this.btn_divide.Size = new System.Drawing.Size(112, 107);
            this.btn_divide.TabIndex = 5;
            this.btn_divide.Text = "/";
            this.btn_divide.UseVisualStyleBackColor = false;
            this.btn_divide.Click += new System.EventHandler(this.btn_divide_Click);
            // 
            // btn_multiply
            // 
            this.btn_multiply.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btn_multiply.Font = new System.Drawing.Font("Arial Black", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_multiply.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_multiply.Location = new System.Drawing.Point(828, 69);
            this.btn_multiply.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_multiply.Name = "btn_multiply";
            this.btn_multiply.Size = new System.Drawing.Size(112, 107);
            this.btn_multiply.TabIndex = 6;
            this.btn_multiply.Text = "x";
            this.btn_multiply.UseVisualStyleBackColor = false;
            this.btn_multiply.Click += new System.EventHandler(this.btn_multiply_Click);
            // 
            // btn_sub
            // 
            this.btn_sub.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btn_sub.Font = new System.Drawing.Font("Arial Black", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_sub.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_sub.Location = new System.Drawing.Point(713, 180);
            this.btn_sub.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_sub.Name = "btn_sub";
            this.btn_sub.Size = new System.Drawing.Size(112, 107);
            this.btn_sub.TabIndex = 7;
            this.btn_sub.Text = "-";
            this.btn_sub.UseVisualStyleBackColor = false;
            this.btn_sub.Click += new System.EventHandler(this.btn_sub_Click);
            // 
            // lbl_answer
            // 
            this.lbl_answer.AutoSize = true;
            this.lbl_answer.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lbl_answer.Location = new System.Drawing.Point(117, 326);
            this.lbl_answer.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_answer.Name = "lbl_answer";
            this.lbl_answer.Size = new System.Drawing.Size(98, 27);
            this.lbl_answer.TabIndex = 8;
            this.lbl_answer.Text = "ANSWER";
            this.lbl_answer.Click += new System.EventHandler(this.label1_Click);
            // 
            // txt_answer
            // 
            this.txt_answer.Location = new System.Drawing.Point(300, 319);
            this.txt_answer.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_answer.Name = "txt_answer";
            this.txt_answer.Size = new System.Drawing.Size(640, 34);
            this.txt_answer.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 27F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(1200, 759);
            this.Controls.Add(this.txt_answer);
            this.Controls.Add(this.lbl_answer);
            this.Controls.Add(this.btn_sub);
            this.Controls.Add(this.btn_multiply);
            this.Controls.Add(this.btn_divide);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.lbl_number2);
            this.Controls.Add(this.lbl_number1);
            this.Controls.Add(this.txt_number2);
            this.Controls.Add(this.txt_number1);
            this.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "MINI CALCULATOR";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_number1;
        private System.Windows.Forms.TextBox txt_number2;
        private System.Windows.Forms.Label lbl_number1;
        private System.Windows.Forms.Label lbl_number2;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_divide;
        private System.Windows.Forms.Button btn_multiply;
        private System.Windows.Forms.Button btn_sub;
        private System.Windows.Forms.Label lbl_answer;
        private System.Windows.Forms.TextBox txt_answer;
    }
}

